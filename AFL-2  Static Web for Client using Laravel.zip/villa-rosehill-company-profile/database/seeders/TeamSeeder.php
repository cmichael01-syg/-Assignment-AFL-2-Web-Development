<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Team;

class TeamSeeder extends Seeder
{
    public function run()
    {
        Team::insert([
            [
                'name' => 'Michael Setiawan',
                'role' => 'General Manager',
                'photo' => 'team1.jpg',
            ],
            [
                'name' => 'Laura Dewi',
                'role' => 'Guest Relations',
                'photo' => 'team2.jpg',
            ],
            [
                'name' => 'Rama Putra',
                'role' => 'Maintenance Supervisor',
                'photo' => 'team3.jpg',
            ],
        ]);
    }
}
