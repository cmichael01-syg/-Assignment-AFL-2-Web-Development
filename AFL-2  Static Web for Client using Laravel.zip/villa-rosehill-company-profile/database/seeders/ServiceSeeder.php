<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Service;

class ServiceSeeder extends Seeder
{
    public function run()
    {
        Service::insert([
            [
                'title' => 'Luxury Villas',
                'description' => 'Spacious villas surrounded by nature with premium amenities.',
                'image' => 'villa1.jpg',
            ],
            [
                'title' => 'Private Pool',
                'description' => 'Enjoy a serene dip in our private pool with a scenic view.',
                'image' => 'pool.jpg',
            ],
            [
                'title' => 'Café & Lounge',
                'description' => 'Relax and unwind at our exclusive café with mountain views.',
                'image' => 'cafe.jpg',
            ],
        ]);
    }
}
