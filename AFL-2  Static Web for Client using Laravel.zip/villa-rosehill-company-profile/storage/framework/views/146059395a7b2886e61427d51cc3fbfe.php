

<?php $__env->startSection('content'); ?>
<div class="text-center py-5 bg-dark text-white">
    <h1 class="display-4 fw-bold">Welcome to Bromo Villa Rosehill</h1>
    <p class="lead">Escape into comfort and nature’s beauty — your serene getaway awaits.</p>
</div>

<div class="container my-5 text-center">
    <h2 class="mb-4">About Us</h2>
    <p class="text-muted">
        Nestled in the scenic hills of Bromo, Villa Rosehill offers tranquility, premium comfort, and stunning mountain views.
        We provide unforgettable stays with warm hospitality. Follow us on Instagram:
        <a href="https://instagram.com/bromovillarosehill" target="_blank">@bromovillarosehill</a> or contact us at <strong>+62 812-3456-7890</strong>.
    </p>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Christian Michael S\Herd\villa-rosehill-company-profile\resources\views/home.blade.php ENDPATH**/ ?>