<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rose Hill Boutique Villa</title>

    <!-- Google Font (Raleway - similar to the logo font) -->
    <link href="https://fonts.googleapis.com/css2?family=Raleway:wght@400;600&display=swap" rel="stylesheet">

    <!-- Bootstrap 5 -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
        body {
            font-family: 'Raleway', sans-serif;
            color: #444;
            background-color: #f7f7f7;
            margin: 0;
            overflow-x: hidden;
        }

        /* Horizontal Scrolling Background */
        .scrolling-bg {
            display: flex;
            width: max-content;
            animation: scroll 40s linear infinite;
        }

        .scrolling-bg img {
            height: 400px;
            object-fit: cover;
            filter: grayscale(40%) brightness(0.9);
        }

        @keyframes scroll {
            0% { transform: translateX(0); }
            100% { transform: translateX(-50%); }
        }

        header {
            background: #e9ecef;
            text-align: center;
            padding: 80px 20px 60px;
            position: relative;
            z-index: 2;
        }

        header img {
            height: 100px;
            margin-bottom: 15px;
        }

        header h1 {
            font-weight: 600;
            font-size: 2rem;
            letter-spacing: 1px;
            color: #555;
        }

        section {
            padding: 70px 0;
        }

        .section-title {
            text-align: center;
            font-weight: 600;
            font-size: 1.8rem;
            margin-bottom: 40px;
            color: #555;
        }

        .services .card {
            border: none;
            background-color: #fff;
            box-shadow: 0 2px 6px rgba(0,0,0,0.08);
            transition: transform 0.3s ease;
        }

        .services .card:hover {
            transform: translateY(-5px);
        }

        .services img {
            height: 280px;
            object-fit: cover;
            width: 100%;
            border-top-left-radius: .5rem;
            border-top-right-radius: .5rem;
            filter: grayscale(20%);
        }

        footer {
            background: #e9ecef;
            text-align: center;
            padding: 20px 0;
            color: #666;
            font-size: 0.9rem;
        }

        /* Overlay gradient on background section */
        .background-container {
            position: relative;
            overflow: hidden;
        }

        .background-container::after {
            content: "";
            position: absolute;
            top: 0; left: 0; right: 0; bottom: 0;
            background: linear-gradient(to bottom, rgba(255,255,255,0.1), #f7f7f7);
            z-index: 1;
        }

        .content-overlay {
            position: relative;
            z-index: 2;
        }
    </style>
</head>
<body>

    <!-- Horizontal Scrolling Landscape Background -->
    <div class="background-container">
        <div class="scrolling-bg">
            <!-- Replace these with your own landscape images later -->
            <img src="images/one.png" alt="">
            <img src="images/two.png" alt="">
            <img src="images/three.png" alt="">
            <img src="images/one.png" alt="">
            <img src="images/two.png" alt="">
            <img src="images/three.png" alt="">
        </div>
    </div>

    <!-- Header -->
    <header class="content-overlay">
        <img src="<?php echo e(asset('images/logo.png')); ?>" alt="Company Logo">
        <h1>Rose Hill Boutique Villa</h1>
        <p>Luxury comfort surrounded by nature’s beauty</p>
    </header>

    <!-- About Section -->
    <section id="about" class="content-overlay container">
        <div class="row align-items-center">
            <div class="col-md-6">
                <h2 class="section-title">About Us</h2>
                <p class="lead mb-3">Welcome to Villa Rose Hill Bromo</p>
                    <p>A boutique villa retreat perched among the rolling hills of Mount Bromo, East Java.
                    </p>

                <p>
                    Nestled at Puncak Bromo Villas A9, Wonokerto, Kec. Sukapura, Kabupaten Probolinggo, our villa offers sweeping 360&deg; views of the surrounding mountains and valleys. Enjoy warm Indonesian hospitality, modern comforts, and a tranquil setting ideal for relaxation, romance, or adventure.
                </p>

                <ul class="list-unstyled ms-3">
                    <li><strong>Accommodation:</strong> Two-bedroom suites with a gazebo lounge and panoramic vantage points.</li>
                    <li><strong>Check-in / Check-out:</strong> Check-in from 4:00 PM · Check-out by 12:00 PM.</li>
                    <li><strong>Amenities:</strong> Free high-speed WiFi, in-villa karaoke, BBQ with JBL speaker setup.</li>
                    <li><strong>Tours:</strong> Local arrangements — jeep to Bromo crater, waterfall hikes, village excursions.</li>
                    <li><strong>Suitable for:</strong> Couples, families, and groups.</li>
                </ul>

                <p class="mt-2">Follow us: <a href="https://instagram.com/villarosehillbromo" target="_blank" rel="noopener">@villarosehillbromo</a></p>
            </div>
            <div class="col-md-6 text-center">
                <img src="images/about.png" class="img-fluid rounded shadow" alt="About">
            </div>
        </div>
    </section>

    <!-- Services Section -->
    <section id="services" class="services content-overlay" style="background-color: #f2f2f2;">
        <div class="container">
            <h2 class="section-title">Our Services</h2>
            <div class="row">
                <div class="col-md-4 mb-4">
                    <div class="card">
                        <img src="images/room.png" alt="Service 1">
                        <div class="card-body">
                            <h5>Luxury Rooms</h5>
                            <p>Spacious and cozy rooms with panoramic views and elegant interiors.</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 mb-4">
                    <div class="card">
                        <img src="images/dining.png" alt="Service 2">
                        <div class="card-body">
                            <h5>Fine Dining</h5>
                            <p>Experience local and international cuisine crafted with passion by our chefs.</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 mb-4">
                    <div class="card">
                        <img src="images/tour.png" alt="Service 3">
                        <div class="card-body">
                            <h5>Nature Tours</h5>
                            <p>Explore the natural wonders of Bromo and nearby destinations with our guided tours.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer>
        &copy; <?php echo e(date('Y')); ?> Rose Hill Boutique Villa · All rights reserved.
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php /**PATH C:\Users\Christian Michael S\Herd\villa-rosehill-company-profile\resources\views/welcome.blade.php ENDPATH**/ ?>