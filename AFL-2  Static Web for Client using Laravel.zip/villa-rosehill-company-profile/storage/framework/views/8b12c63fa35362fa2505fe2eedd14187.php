

<?php $__env->startSection('content'); ?>
<div class="container my-5">
    <h2 class="text-center mb-4">Gallery</h2>
    <p class="text-center text-muted mb-5">A glimpse into the serene beauty of Bromo Villa Rosehill.</p>
    <div class="row g-4">
        <div class="col-md-4"><img src="<?php echo e(asset('images/gallery1.jpg')); ?>" class="img-fluid rounded shadow"></div>
        <div class="col-md-4"><img src="<?php echo e(asset('images/gallery2.jpg')); ?>" class="img-fluid rounded shadow"></div>
        <div class="col-md-4"><img src="<?php echo e(asset('images/gallery3.jpg')); ?>" class="img-fluid rounded shadow"></div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Christian Michael S\Herd\villa-rosehill-company-profile\resources\views/gallery.blade.php ENDPATH**/ ?>