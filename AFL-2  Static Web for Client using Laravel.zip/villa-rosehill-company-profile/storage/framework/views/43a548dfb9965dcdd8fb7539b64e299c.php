

<?php $__env->startSection('content'); ?>
<div class="container my-5">
    <h2 class="text-center mb-5">Our Services</h2>
    <div class="row">
        <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-4 mb-4">
            <div class="card h-100 shadow-sm">
                <img src="<?php echo e(asset('images/'.$service->image)); ?>" class="card-img-top img-fluid" alt="<?php echo e($service->title); ?>">
                <div class="card-body">
                    <h5 class="card-title"><?php echo e($service->title); ?></h5>
                    <p class="card-text"><?php echo e($service->description); ?></p>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <h2 class="text-center mt-5 mb-4">Meet Our Team</h2>
    <div class="row">
        <?php $__currentLoopData = $team; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-4 mb-4 text-center">
            <img src="<?php echo e(asset('images/'.$member->photo)); ?>" class="rounded-circle mb-3" style="width:150px;height:150px;object-fit:cover;">
            <h5><?php echo e($member->name); ?></h5>
            <p class="text-muted"><?php echo e($member->role); ?></p>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Christian Michael S\Herd\villa-rosehill-company-profile\resources\views/profile.blade.php ENDPATH**/ ?>