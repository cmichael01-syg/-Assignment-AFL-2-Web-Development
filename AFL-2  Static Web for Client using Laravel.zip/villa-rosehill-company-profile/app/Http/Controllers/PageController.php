<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Service;
use App\Models\Team;

class PageController extends Controller
{
    public function home()
    {
        return view('home');
    }

    public function profile()
    {
        $services = Service::all();
        $team = Team::all();
        return view('profile', compact('services', 'team'));
    }

    public function gallery()
    {
        return view('gallery');
    }
}
